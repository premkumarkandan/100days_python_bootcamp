rand_x = []
rand_y = []

for _ in range(-300, 300, 10):
    rand_x.append(_)
    rand_y.append(_)
print(rand_y)
print(rand_x)
